export class Response {
    result: string;
    message: string;
    data: string;
}
